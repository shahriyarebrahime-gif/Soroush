import type {Metadata} from "next"; import "./globals.css";
export const metadata:Metadata={title:"سروش | دفتر فنی و لوازم‌التحریر",description:"فروشگاه آنلاین سروش در اصفهان"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fa" dir="rtl"><body>{children}</body></html>}