export const ADMIN_EMAILS=["admin@soroush-shop.ir","manager@soroush-shop.ir"];
export const products=[
{id:1,name:"دفتر ۱۰۰ برگ کلاسیک",category:"دفتر",price:89000,emoji:"📓",tag:"پرفروش"},
{id:2,name:"خودکار آبی یونی",category:"نوشت‌افزار",price:45000,emoji:"🖊️",tag:"محبوب"},
{id:3,name:"کاغذ A4 هشتاد گرم",category:"کاغذ",price:295000,emoji:"📄",tag:"اقتصادی"},
{id:4,name:"زونکن اداری A4",category:"اداری",price:165000,emoji:"🗂️",tag:"پیشنهاد"},
{id:5,name:"مداد مشکی HB",category:"نوشت‌افزار",price:28000,emoji:"✏️",tag:""},
{id:6,name:"ماژیک وایت‌برد",category:"نوشت‌افزار",price:79000,emoji:"🖍️",tag:""},
{id:7,name:"پوشه دکمه‌دار",category:"اداری",price:52000,emoji:"📁",tag:""},
{id:8,name:"پاک‌کن نرم",category:"نوشت‌افزار",price:19000,emoji:"◻️",tag:""}];
export const toman=(n:number)=>new Intl.NumberFormat("fa-IR").format(n)+" تومان";